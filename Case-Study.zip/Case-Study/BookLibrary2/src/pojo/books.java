package pojo;

public class books 
{
private int id;
private String name, author, subject;
private float price;
private int isbn;

public books() {
	// TODO Auto-generated constructor stub
}

public books(int id, String name, String author, String subject, float price, int isbn) {
	super();
	this.id = id;
	this.name = name;
	this.author = author;
	this.subject = subject;
	this.price = price;
	this.isbn = isbn;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getAuthor() {
	return author;
}

public void setAuthor(String author) {
	this.author = author;
}

public String getSubject() {
	return subject;
}

public void setSubject(String subject) {
	this.subject = subject;
}

public float getPrice() {
	return price;
}

public void setPrice(float price) {
	this.price = price;
}

public int getIsbn() {
	return isbn;
}

public void setIsbn(int isbn) {
	this.isbn = isbn;
}

@Override
public String toString() {
	return String.format("%-5d%-20s%-20s%-50s%-10.2f%-5d", this.id, this.name, this.author, this.subject, this.price, this.isbn);
}


}
