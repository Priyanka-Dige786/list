package pojo;

public class payments
{
private int id, userid;
private float amount;
private String type, transction_time, nextpayment_duedate;

public payments() {   }

public payments(int id, int userid, float amount, String type, String transction_time, String nextpayment_duedate) {
	super();
	this.id = id;
	this.userid = userid;
	this.amount = amount;
	this.type = type;
	this.transction_time = transction_time;
	this.nextpayment_duedate = nextpayment_duedate;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public int getUserid() {
	return userid;
}

public void setUserid(int userid) {
	this.userid = userid;
}

public float getAmount() {
	return amount;
}

public void setAmount(float amount) {
	this.amount = amount;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public String getTransction_time() {
	return transction_time;
}

public void setTransction_time(String transction_time) {
	this.transction_time = transction_time;
}

public String getNextpayment_duedate() {
	return nextpayment_duedate;
}

public void setNextpayment_duedate(String nextpayment_duedate) {
	this.nextpayment_duedate = nextpayment_duedate;
}

@Override
public String toString() {
	return String.format("%-5d%-8d%-10.2f%-20s%-20s%-20s", this.id, this.userid, this.amount, this.type, this.transction_time, this.nextpayment_duedate);
}


}
