package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import test.Program;
import utils.DBUtils;

public class Owner {
	Scanner sc =new Scanner(System.in);
	private Connection connection;
	private PreparedStatement updateStatement;
	private PreparedStatement updatePassword;
	public Owner() throws Exception 
	{
	  this.connection = DBUtils.getConnection();
	  this.updateStatement = connection.prepareStatement("update user set email = ?, phone = ? where id = ?");  
	  this.updatePassword  = connection.prepareStatement("update user set password = ? where id = ?");
	}

	public void ownerFunction(int[] id) throws Exception 
	{
		int choice;
		while( ( choice = menu( ) ) != 0 )
		{
			switch( choice )
			{
			case 1: edit(id);
			        System.out.println("Updated successfully..");
			case 2: editPassword(id);
			case 3:
			case 4:
			case 5:
		
			
			}
		}
		
	}

	private void editPassword(int[] id) throws Exception
	{
		System.out.println("new password : ");
		String pass = sc.next();
		
		this.updatePassword.setString(1, pass);
		this.updatePassword.setInt(2, id[0]);
	}

	private void edit(int[] id) throws Exception 
	{
		System.out.print("new email : ");
        String email = sc.next();
        System.out.print("new mobile : ");
        String phone = sc.next();
    
        this.updateStatement.setString(1, email);
        this.updateStatement.setString(2, phone);
        this.updateStatement.setInt(3, id[0]);
}
	private int menu() {
		System.out.println("0.sign out");
		System.out.println ("1.edit profile");
		System.out.println ("2.change password");
		System.out.println ("3.subjectwise copies report");
		System.out.println ("4.bookwise copies report");
		System.out.println ("5.fees/fine report");
		return sc.nextInt();
	}

}