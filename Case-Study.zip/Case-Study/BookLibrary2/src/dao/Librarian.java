package dao;

public class Librarian {

}
