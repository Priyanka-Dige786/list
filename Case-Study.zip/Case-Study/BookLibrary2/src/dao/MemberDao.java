package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.protocol.Resultset;

import pojo.books;
import pojo.user;
import utils.DBUtils;

public class MemberDao implements AutoCloseable
{
  private Connection connection;
  private PreparedStatement insertStatement;
  private PreparedStatement updateStatement;
  private PreparedStatement deleteStatement;
  private PreparedStatement selectStatement;
  
  public MemberDao() throws Exception {
	this.connection = DBUtils.getConnection();
	this.updateStatement = connection.prepareStatement("update user set password=? where id=?");
	this.selectStatement = connection.prepareStatement("select count(bookid) from copies where bookid=? and status='Available'");
    this.selectStatement = connection.prepareStatement("select count(id) from issuerecord");
  
  }
  
@Override
public void close() throws Exception {
	// TODO Auto-generated method stub
	
}

public int UpdatePassword(String password, int id) throws Exception {
	this.updateStatement.setString(1, password);
	this.updateStatement.setInt(2, id);
	return this.updateStatement.executeUpdate();
}

public List<books> findBook(String name) throws Exception {
	//this.selectStatement.setString(1, name);
	this.selectStatement = connection.prepareStatement("select * from books where name LIKE '%"+name+"%'");
	//this.selectStatement = connection.prepareStatement(" SELECT * FROM books WHERE name LIKE '%java%'");
	List<books> BookList = new ArrayList<books>();
	try(ResultSet rs = this.selectStatement.executeQuery())
	{
		while(rs.next())
		{
			books Books = new books(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getFloat(5), rs.getInt(6));
		    BookList.add(Books);
		}
	}
	return BookList;
}

public int CheckCopies(int bookid) throws Exception
{
	this.selectStatement.setInt(1, bookid);
    ResultSet rs = this.selectStatement.executeQuery();
    while(rs.next())
    {
    	int result = rs.getInt(1);
    	return result;
    }
	return 0;
}

public int issueBooks() throws Exception
{
    ResultSet rs = this.selectStatement.executeQuery();
    while(rs.next())
    {
    	int result = rs.getInt(1);
    	return result;
    }
	return 0;
}
}
