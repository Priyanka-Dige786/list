package test;

import java.util.List;
import java.util.Scanner;

import dao.MemberDao;
import pojo.books;
import pojo.user;

public class Program {

	static Scanner sc = new Scanner(System.in);
	public static int menuList()
	{
		System.out.println("0. Exit");
		System.out.println("1. SignIn");
		System.out.println("2. SignUp");
		System.out.println("Enter Choice");
		return sc.nextInt();
	}
	public static int menuListUser()
	{
		System.out.println("0.SignOut");
		System.out.println("1.edit Profile");
		System.out.println("2.Change Password");
		System.out.println("3.Find book by name");
		System.out.println("4.Check book availability");
		System.out.println("5.List issued books");
		System.out.println("6.Payment History");
		System.out.println("Enter Choice");
		return sc.nextInt();
	}
	private static void printBookList(List<books> Books) {
		if(Books != null)
		{
			for(books book : Books)
			{
				System.out.println(book.toString());
			}
		}
		
	}
	
	public static void main(String[] args)
	{
		try(MemberDao dao = new MemberDao())
		{
			int choice;
			
			while((choice = Program.menuList()) != 0)
			{
				switch(choice)
				{
				case 1:
					user User = new user();
					System.out.println("Email : ");
					String userid = sc.next();
					System.out.println("Password : ");
					String UserPassword = sc.next();
					String userEmail = new String("user2@gmail.com");
					String userPassword = new String("user@1234");
					if(userid.equals(userEmail) && UserPassword.equals(userPassword))
					{
						while((choice = Program.menuListUser())!=0)
						{
							switch(choice)
							{
							case 1:
							
								break;
							case 2:
								System.out.println("enter your id");
								int id = sc.nextInt();
								System.out.println("enter new paasord");
								String password = sc.next();
								dao.UpdatePassword(password, id);
								System.out.println("password updated");
								break;
							case 3:
								System.out.println("Enter book name :");
								String name = sc.next();
								
								List<books> Books =dao.findBook(name);
								Program.printBookList(Books);
								break;
							case 4:
								System.out.println("Enter BookId : ");
								int bookid = sc.nextInt();
								int availableCopies = dao.CheckCopies(bookid);
								System.out.println("Available Books are : "+availableCopies);
								break;
							case 5:
								int noOfIssueBooks = dao.issueBooks();
								System.out.println("No Of Issue Books Are : "+ noOfIssueBooks);
								break;
							case 6:
								break;
							}
						}
					}
						
					break;
				case 2: 
					break;
				}
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	 
    
	}
	

}
