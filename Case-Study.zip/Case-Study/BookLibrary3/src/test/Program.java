package test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

import dao.Librarian;
import dao.MemberDao;
import dao.Owner;
import pojo.books;
import pojo.user;
import utils.DBUtils;

public class Program {

	static Scanner sc = new Scanner(System.in);
	public static int menuList()
	{
		System.out.println("0. Exit");
		System.out.println("1. SignIn");
		System.out.println("2. SignUp");
		System.out.println("Enter Choice");
		return sc.nextInt();
	}
	public static int menuListUser()
	{
		System.out.println("0.SignOut");
		System.out.println("1.edit Profile");
		System.out.println("2.Change Password");
		System.out.println("3.Find book by name");
		System.out.println("4.Check book availability");
		System.out.println("5.List issued books");
		System.out.println("6.Payment History");
		System.out.println("Enter Choice");
		return sc.nextInt();
	}
	
		public static void main(String[] args) throws Exception 
		{
			int choice;
			while( ( choice = Program.menuList( ) ) != 0 )
			{
				switch( choice )
				{
				case 1: int [] id  = new int [1];
				       String role = Program.findRole(id);
				       Program.createReferance(role,id);
				case 2:
			
				
				}
			}
		}
		private static void createReferance(String role, int[] id) throws Exception 
		{
			String owner = new String("owner");
			String librarian = new String("librarian");
			String member = new String("member");
			
			if(role.equals(owner))
			{
				Owner o = new Owner();
				o.ownerFunction(id);
			}
			else if(role.equals(librarian))
			{
				Librarian l = new Librarian();
			}
			else if(role.equals(member))
			{
				MemberDao m =new MemberDao();
				m.memberFunction();
			}
		}
		private static String findRole(int[] id) 
		{
			System.out.print("email : ");
	        String email = sc.next();
	        System.out.print("password : ");
	        String password = sc.next();
	        String role = "";
			try( Connection connection = DBUtils.getConnection();
	    			)
	    		{
				PreparedStatement selectStatement = connection.prepareStatement("Select role from user where email =? and password =?");
				//PreparedStatement selectStatement = connection.prepareStatement("Select role from user where email =' "+email+ "' and password =' "+password+" '");
	    			//String sql =  "Select role from user where email =' "+email+ "' and password =' "+password+" '";
				selectStatement.setString(1, email);
				selectStatement.setString(2, password);
	    			try( ResultSet rs = selectStatement.executeQuery();)
	    			{
	    				while(rs.next())
	    				{
	    					role = rs.getString(6);
	    					System.out.println(role);
	    					id [0] = rs.getInt(1);
	    					return role;
	    				}
	    			}
	    		}
	    		catch( Exception ex )
	    		{
	    			ex.printStackTrace();
	    		}
	        
			return role;
		}
	

}
